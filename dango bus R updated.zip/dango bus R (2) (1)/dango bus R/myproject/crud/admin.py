from django.contrib import admin
from .models import Bus

admin.site.register(Bus)

# Register your models here.
