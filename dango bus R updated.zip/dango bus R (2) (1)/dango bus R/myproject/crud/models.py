from django.db import models
from datetime import datetime,date

# Create your models here.
class Bus(models.Model):
    your_dept=models.CharField(max_length=5)
    your_destination=models.CharField(max_length=55)
    your_date=models.DateField(blank=True,null=True)
    your_scheldule=models.CharField(max_length=20,null=True)
    your_name=models.CharField(max_length=25,null=True)
    your_email=models.CharField(max_length=20,null=True)
    your_phone=models.CharField(max_length=20,null=True)

    
    def __str__(self):
        return self.your_dept




