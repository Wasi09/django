from distutils import dep_util

from email import message
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from .forms import BusForm
from.models import Bus
from django.core.mail import send_mail
from django.conf import settings



def find_bus(request):
    if request.method=="POST":
        your_dept=request.POST.get('your_dept')
        your_destination=request.POST.get('your_destination')
        your_date=request.POST.get('your_date')
        your_scheldule=request.POST.get('your_scheldule')
        your_name=request.POST.get('your_name')
        your_email=request.POST.get('your_email')
        your_phone=request.POST.get('your_phone')


        send_mail(
           'your_name',
           'your_phone',
           'your_email',
            ['waseemhassan0316@gmail.com'],
        )





        en=Bus(your_dept=your_dept,your_destination=your_destination,your_date=your_date,your_scheldule=your_scheldule,your_name=your_name,your_email=your_email,your_phone=your_phone)
        en.save()


    return render(request,"findbus.html")
     
    


    
     

       
